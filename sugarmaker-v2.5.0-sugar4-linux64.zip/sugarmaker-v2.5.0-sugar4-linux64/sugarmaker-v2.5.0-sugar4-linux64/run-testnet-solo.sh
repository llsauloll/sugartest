./sugarmaker -a YespowerSugar -o http://127.0.0.1:44229 -u RPCUSER -p RPCPASSWORD --coinbase-addr=hU4hajEmWVYBikYapkai7sv2o4D5WQYcvU -t1
