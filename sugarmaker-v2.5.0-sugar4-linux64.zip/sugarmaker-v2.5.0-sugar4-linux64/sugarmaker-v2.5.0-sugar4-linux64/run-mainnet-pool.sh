./sugarmaker -a YespowerSugar -o stratum+tcp://pool.swampthing.net:9244 -u hU4hajEmWVYBikYapkai7sv2o4D5WQYcvU -t1
